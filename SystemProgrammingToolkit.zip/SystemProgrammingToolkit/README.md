# System Programming Toolkit (C# / Windows Forms)

A single Windows Forms project with a **main menu** that opens **five modules**.
Every button performs a real operating-system operation and reports the result in a live log console.

| # | Module | What the buttons do |
|---|--------|---------------------|
| 1 | **Process Management** | Start, Stop (Kill), Close gracefully, **Pause (suspend)**, **Resume**, List/refresh (with filter + auto-refresh), Details, Set priority, Run a child process and capture its stdout/stderr |
| 2 | **Threads & Synchronization** | Create threads (managed + OS thread ids), race condition vs `lock` vs `Interlocked`, named `Mutex`, `Semaphore`, producer/consumer, thread pool + `Parallel.For`, deadlock + avoidance |
| 3 | **File System & I/O** | Create/read/append/copy/move/delete, file info + read-only attribute, directory tree, drives, binary I/O, buffering benchmark, file locking (sharing violation), `FileSystemWatcher` |
| 4 | **Memory Management** | `GlobalMemoryStatusEx`, `GetSystemInfo`, process memory, managed allocations, unmanaged heap, `VirtualAlloc` reserve/commit/decommit/release, memory-mapped files, GC generations/LOH/weak refs, stack vs heap |
| 5 | **Inter-Process Communication** | Named pipes (server/client), anonymous pipes, shared memory, named kernel events, TCP sockets, "Open 2nd Instance" for real cross-process tests |

## Project layout

```
SystemProgrammingToolkit.sln
SystemProgrammingToolkit/
  Program.cs                  entry point
  MainForm.cs                 main menu
  Common/ModuleFormBase.cs    shared layout, thread-safe Log(), button helpers
  Native/NativeMethods.cs     P/Invoke (kernel32 / ntdll) declarations
  Modules/
    ProcessManagementForm.cs
    ThreadingForm.cs
    FileSystemForm.cs
    MemoryForm.cs
    IpcForm.cs
```

The UI is built in code (no `.Designer.cs` files) so it is easy to read, diff and review in Git.

## Requirements

* **Windows 10/11** to *run* (Windows Forms and Win32 APIs are Windows-only).
* **.NET SDK 10** (or change `TargetFramework` to `net8.0-windows` in the `.csproj` for .NET 8).
* Visual Studio 2022 17.14+ / Visual Studio 2026 with the ".NET desktop development" workload (or just the `dotnet` CLI).

## Build and run

**Visual Studio:** open `SystemProgrammingToolkit.sln` -> press **F5**.

**CLI (Windows):**
```bash
dotnet run --project SystemProgrammingToolkit
```

## Using it from Ubuntu / macOS / other systems

Windows Forms apps cannot *run* natively on Linux or macOS, but you can clone, edit and **build** the project there:

```bash
# Ubuntu: install the SDK once
sudo apt update && sudo apt install -y dotnet-sdk-10.0   # or follow https://learn.microsoft.com/dotnet/core/install/linux

dotnet build SystemProgrammingToolkit.sln -p:EnableWindowsTargeting=true
dotnet publish SystemProgrammingToolkit/SystemProgrammingToolkit.csproj \
    -c Release -r win-x64 --self-contained -o publish      # produces a Windows .exe folder
```
Copy the `publish/` folder to a Windows machine to run it. The included GitHub Actions workflow
(`.github/workflows/build.yml`) does this automatically and uploads the Windows build as a downloadable artifact.

## Push to GitHub

```bash
cd SystemProgrammingToolkit            # the folder containing the .sln
git init -b main
git add .
git commit -m "Initial commit: System Programming Toolkit"

# 1) create an EMPTY repository on github.com (no README), then:
git remote add origin https://github.com/<your-username>/SystemProgrammingToolkit.git
git push -u origin main

# or, with the GitHub CLI:
gh repo create SystemProgrammingToolkit --public --source=. --push
```

## Notes and safety

* **Stop (Kill)** and **Pause** ask for confirmation / refuse PIDs <= 4 and this app itself. Pausing a process owned by another user or an elevated process needs **Run as administrator**.
* File operations stay inside `%TEMP%\SystemProgrammingToolkit`.
* Memory buttons can allocate up to 1 GB per click; use the "Free" buttons afterwards.
* IPC demos use loopback (127.0.0.1:54321) and local pipe/shared-memory names only.
