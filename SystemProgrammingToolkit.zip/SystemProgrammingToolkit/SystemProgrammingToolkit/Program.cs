namespace SystemProgrammingToolkit;

internal static class Program
{
    [STAThread]
    private static void Main()
    {
        if (!OperatingSystem.IsWindows())
        {
            Console.Error.WriteLine("This application uses Windows Forms and Win32 APIs and must run on Windows.");
            return;
        }

        ApplicationConfiguration.Initialize();
        Application.Run(new MainForm());
    }
}
