using System.Runtime.InteropServices;
using System.Security.Principal;
using SystemProgrammingToolkit.Modules;

namespace SystemProgrammingToolkit;

/// <summary>Main menu: one button per system-programming module.</summary>
public sealed class MainForm : Form
{
    public MainForm()
    {
        Text = "System Programming Toolkit - C# / Windows Forms";
        StartPosition = FormStartPosition.CenterScreen;
        ClientSize = new Size(720, 650);
        FormBorderStyle = FormBorderStyle.FixedSingle;
        MaximizeBox = false;
        Font = new Font("Segoe UI", 10F);

        Controls.Add(new Label
        {
            Text = "System Programming Toolkit",
            Font = new Font("Segoe UI", 22F, FontStyle.Bold),
            AutoSize = true,
            Location = new Point(24, 14)
        });
        Controls.Add(new Label
        {
            Text = "Hands-on demonstrations of how an application talks to the operating system.",
            ForeColor = Color.DimGray,
            AutoSize = true,
            Location = new Point(28, 68)
        });

        int y = 108;
        y = AddModule("1.  Process Management", "Start, stop, pause, resume, prioritise, inspect and list processes", y, Open<ProcessManagementForm>);
        y = AddModule("2.  Threads && Synchronization", "Threads, race conditions, lock, Interlocked, Mutex, Semaphore, producer-consumer", y, Open<ThreadingForm>);
        y = AddModule("3.  File System && I/O", "File CRUD, binary I/O, buffering benchmark, file locking, FileSystemWatcher", y, Open<FileSystemForm>);
        y = AddModule("4.  Memory Management", "Managed/unmanaged heap, VirtualAlloc, memory-mapped files, GC, stack vs heap", y, Open<MemoryForm>);
        y = AddModule("5.  Inter-Process Communication", "Named pipes, anonymous pipes, shared memory, TCP sockets, named events", y, Open<IpcForm>);

        var exit = new Button { Text = "Exit", Size = new Size(120, 36), Location = new Point(576, y + 6) };
        exit.Click += (_, _) => Close();
        Controls.Add(exit);

        Controls.Add(new Label
        {
            Text = BuildSystemSummary(),
            ForeColor = Color.DimGray,
            Font = new Font("Segoe UI", 8.5F),
            Location = new Point(24, y + 6),
            Size = new Size(540, 40)
        });
    }

    private int AddModule(string title, string description, int y, Action open)
    {
        var button = new Button
        {
            Text = $"{title}\n{description}",
            Size = new Size(672, 70),
            Location = new Point(24, y),
            TextAlign = ContentAlignment.MiddleLeft,
            Padding = new Padding(16, 0, 0, 0),
            UseMnemonic = false
        };
        // "&&" was used above for readability in source; with UseMnemonic=false we show a single "&".
        button.Text = button.Text.Replace("&&", "&");
        button.Click += (_, _) => open();
        Controls.Add(button);
        return y + 80;
    }

    private void Open<T>() where T : Form, new()
    {
        var existing = Application.OpenForms.OfType<T>().FirstOrDefault();
        if (existing != null)
        {
            if (existing.WindowState == FormWindowState.Minimized) existing.WindowState = FormWindowState.Normal;
            existing.Activate();
            return;
        }
        new T().Show(this);
    }

    private static string BuildSystemSummary()
    {
        bool admin;
        using (var identity = WindowsIdentity.GetCurrent())
            admin = new WindowsPrincipal(identity).IsInRole(WindowsBuiltInRole.Administrator);

        return $"OS: {RuntimeInformation.OSDescription}   |   CPUs: {Environment.ProcessorCount}\n" +
               $"{RuntimeInformation.FrameworkDescription}   |   PID: {Environment.ProcessId}   |   Elevated: {(admin ? "yes" : "no")}";
    }
}
