using System.IO.MemoryMappedFiles;
using System.IO.Pipes;
using System.Net;
using System.Net.Sockets;
using System.Text;
using SystemProgrammingToolkit.Common;

namespace SystemProgrammingToolkit.Modules;

/// <summary>
/// Module 5 - Inter-process communication (IPC).
/// Concepts: named pipes, anonymous pipes, shared memory (named memory-mapped file),
/// TCP sockets over loopback, named kernel events for signalling.
/// Tip: use "Open 2nd Instance" to run a second copy of this program and talk to it for real.
/// </summary>
public sealed class IpcForm : ModuleFormBase
{
    private const string PipeName = "SysProgToolkit.Pipe";
    private const string SharedMemoryName = "SysProgToolkit_SharedMemory";
    private const string EventName = @"Local\SysProgToolkit_Event";
    private const int TcpPort = 54321;
    private const int SharedMemorySize = 4096;

    private readonly TextBox _txtMessage = new() { Text = "Hello via IPC!", Width = 360 };

    private CancellationTokenSource? _pipeCts;
    private CancellationTokenSource? _tcpCts;
    private TcpListener? _tcpListener;
    private MemoryMappedFile? _sharedMemory;
    private EventWaitHandle? _event;

    public IpcForm() : base(
        "Inter-Process Communication",
        "Exchange data between threads, applications and processes using pipes, shared memory, sockets and kernel events.",
        contentHeight: 44)
    {
        var bar = new FlowLayoutPanel { Dock = DockStyle.Fill };
        bar.Controls.AddRange(new Control[] { MakeLabel("Message:"), _txtMessage });
        ContentPanel.Controls.Add(bar);

        AddButton("Pipe: Start Server", StartPipeServer);
        AddAsyncButton("Pipe: Send Message", PipeSendAsync);
        AddButton("Pipe: Stop Server", StopPipeServer);
        AddAsyncButton("Anonymous Pipe Demo", AnonymousPipeDemoAsync);
        NewRow();
        AddButton("Shared Memory: Write", SharedMemoryWrite);
        AddButton("Shared Memory: Read", SharedMemoryRead);
        AddButton("Event: Signal", SignalEvent);
        AddAsyncButton("Event: Wait (15 s)", WaitForEventAsync);
        NewRow();
        AddButton("TCP: Start Server", StartTcpServer);
        AddAsyncButton("TCP: Send Message", TcpSendAsync);
        AddButton("TCP: Stop Server", StopTcpServer);
        AddButton("Open 2nd Instance", OpenSecondInstance);
    }

    // ---- named pipes -----------------------------------------------------------------------

    private void StartPipeServer()
    {
        if (_pipeCts != null) { Log("Pipe server is already running."); return; }
        _pipeCts = new CancellationTokenSource();
        var token = _pipeCts.Token;
        _ = Task.Run(() => PipeServerLoopAsync(token));
        Log($"Named pipe server listening on \\\\.\\pipe\\{PipeName}");
    }

    private async Task PipeServerLoopAsync(CancellationToken token)
    {
        try
        {
            while (!token.IsCancellationRequested)
            {
                try
                {
                    await using var server = new NamedPipeServerStream(
                        PipeName, PipeDirection.InOut, NamedPipeServerStream.MaxAllowedServerInstances,
                        PipeTransmissionMode.Byte, PipeOptions.Asynchronous);

                    await server.WaitForConnectionAsync(token);

                    using var reader = new StreamReader(server, Encoding.UTF8, false, 1024, leaveOpen: true);
                    using var writer = new StreamWriter(server, new UTF8Encoding(false), 1024, leaveOpen: true) { AutoFlush = true };

                    string? message = await reader.ReadLineAsync(token);
                    Log($"[Pipe server] received: \"{message}\"");
                    await writer.WriteLineAsync($"ECHO: {message?.ToUpperInvariant()}  (from PID {Environment.ProcessId})");
                    server.WaitForPipeDrain();   // let the client read the reply before we close
                }
                catch (IOException ex)
                {
                    Log($"[Pipe server] client error: {ex.Message}");
                    await Task.Delay(200, token);
                }
            }
        }
        catch (OperationCanceledException) { }
        catch (Exception ex) { Log($"[Pipe server] fatal error: {ex.Message}"); }
        Log("[Pipe server] stopped.");
    }

    private async Task PipeSendAsync()
    {
        try
        {
            using var client = new NamedPipeClientStream(".", PipeName, PipeDirection.InOut, PipeOptions.Asynchronous);
            await client.ConnectAsync(3000);

            using var writer = new StreamWriter(client, new UTF8Encoding(false), 1024, leaveOpen: true) { AutoFlush = true };
            using var reader = new StreamReader(client, Encoding.UTF8, false, 1024, leaveOpen: true);

            await writer.WriteLineAsync(_txtMessage.Text);
            Log($"[Pipe client] sent: \"{_txtMessage.Text}\"");
            string? reply = await reader.ReadLineAsync();
            Log($"[Pipe client] reply: \"{reply}\"");
        }
        catch (TimeoutException)
        {
            Log("[Pipe client] could not connect. Start the pipe server first (in this window or in another instance).");
        }
    }

    private void StopPipeServer()
    {
        if (_pipeCts == null) { Log("Pipe server is not running."); return; }
        _pipeCts.Cancel();
        _pipeCts.Dispose();
        _pipeCts = null;
    }

    private async Task AnonymousPipeDemoAsync()
    {
        Log("Anonymous pipes are one-way and unnamed. Normally the client handle is inherited by a child process;");
        Log("here both ends live in this process on different threads to keep the demo self-contained.");

        using var server = new AnonymousPipeServerStream(PipeDirection.Out, HandleInheritability.None);
        using var client = new AnonymousPipeClientStream(PipeDirection.In, server.ClientSafePipeHandle);

        var writerTask = Task.Run(() =>
        {
            using var writer = new StreamWriter(server) { AutoFlush = true };
            for (int i = 1; i <= 3; i++)
            {
                writer.WriteLine($"{_txtMessage.Text} #{i}");
                Log($"  [writer thread] sent message {i}");
                Thread.Sleep(250);
            }
        });

        using var reader = new StreamReader(client);
        string? line;
        while ((line = await reader.ReadLineAsync()) != null)
            Log($"  [reader] got: {line}");

        await writerTask;
        Log("Writer closed its end -> reader saw end-of-stream.");
    }

    // ---- shared memory ---------------------------------------------------------------------

    private void SharedMemoryWrite()
    {
        byte[] data = Encoding.UTF8.GetBytes(_txtMessage.Text);
        if (data.Length > SharedMemorySize - 4) throw new InvalidOperationException("Message too long for the 4 KB shared block.");

        // The named mapping lives as long as at least one handle to it is open - we keep ours in a field.
        _sharedMemory ??= MemoryMappedFile.CreateOrOpen(SharedMemoryName, SharedMemorySize);
        using var view = _sharedMemory.CreateViewAccessor(0, SharedMemorySize);
        view.Write(0, data.Length);
        view.WriteArray(4, data, 0, data.Length);
        view.Flush();
        Log($"Wrote {data.Length} bytes into shared memory '{SharedMemoryName}'. Another process can read it now.");
    }

    private void SharedMemoryRead()
    {
        try
        {
            using var mmf = MemoryMappedFile.OpenExisting(SharedMemoryName);
            using var view = mmf.CreateViewAccessor(0, SharedMemorySize);
            int length = view.ReadInt32(0);
            if (length < 0 || length > SharedMemorySize - 4) { Log("Shared memory contains no valid message yet."); return; }
            var data = new byte[length];
            view.ReadArray(4, data, 0, length);
            Log($"Read from shared memory: \"{Encoding.UTF8.GetString(data)}\"");
        }
        catch (FileNotFoundException)
        {
            Log("Shared memory does not exist yet. Press 'Shared Memory: Write' first (here or in another instance).");
        }
    }

    // ---- named event -----------------------------------------------------------------------

    private EventWaitHandle GetEvent() =>
        _event ??= new EventWaitHandle(false, EventResetMode.AutoReset, EventName);

    private void SignalEvent()
    {
        GetEvent().Set();
        Log($"Signalled kernel event '{EventName}'. One waiting thread (in any process) is released.");
    }

    private async Task WaitForEventAsync()
    {
        var handle = GetEvent();
        Log("Waiting for the named event (up to 15 s)... press 'Event: Signal' here or in a second instance.");
        bool signalled = await Task.Run(() => handle.WaitOne(TimeSpan.FromSeconds(15)));
        Log(signalled ? "Event signalled - wait satisfied." : "Timed out waiting for the event.");
    }

    // ---- TCP sockets -----------------------------------------------------------------------

    private void StartTcpServer()
    {
        if (_tcpListener != null) { Log("TCP server is already running."); return; }

        var listener = new TcpListener(IPAddress.Loopback, TcpPort);
        listener.Start();
        _tcpListener = listener;
        _tcpCts = new CancellationTokenSource();
        var token = _tcpCts.Token;
        Log($"TCP server listening on 127.0.0.1:{TcpPort}");

        _ = Task.Run(async () =>
        {
            try
            {
                while (!token.IsCancellationRequested)
                {
                    using var client = await listener.AcceptTcpClientAsync(token);
                    using var stream = client.GetStream();
                    using var reader = new StreamReader(stream, Encoding.UTF8);
                    using var writer = new StreamWriter(stream, new UTF8Encoding(false)) { AutoFlush = true };

                    string? message = await reader.ReadLineAsync(token);
                    Log($"[TCP server] {client.Client.RemoteEndPoint} sent: \"{message}\"");
                    await writer.WriteLineAsync($"ECHO: {message}  (from PID {Environment.ProcessId})");
                }
            }
            catch (OperationCanceledException) { }
            catch (ObjectDisposedException) { }
            catch (SocketException) { }
            catch (Exception ex) { Log($"[TCP server] error: {ex.Message}"); }
            Log("[TCP server] stopped.");
        });
    }

    private async Task TcpSendAsync()
    {
        try
        {
            using var client = new TcpClient();
            using var cts = new CancellationTokenSource(3000);
            await client.ConnectAsync(IPAddress.Loopback, TcpPort, cts.Token);
            using var stream = client.GetStream();
            using var writer = new StreamWriter(stream, new UTF8Encoding(false)) { AutoFlush = true };
            using var reader = new StreamReader(stream, Encoding.UTF8);

            await writer.WriteLineAsync(_txtMessage.Text);
            Log($"[TCP client] sent: \"{_txtMessage.Text}\"");
            Log($"[TCP client] reply: \"{await reader.ReadLineAsync()}\"");
        }
        catch (Exception ex) when (ex is SocketException or OperationCanceledException)
        {
            Log("[TCP client] could not connect. Start the TCP server first.");
        }
    }

    private void StopTcpServer()
    {
        if (_tcpListener == null) { Log("TCP server is not running."); return; }
        _tcpCts?.Cancel();
        _tcpListener.Stop();
        _tcpCts?.Dispose();
        _tcpCts = null;
        _tcpListener = null;
    }

    // ---- helpers ---------------------------------------------------------------------------

    private void OpenSecondInstance()
    {
        string? exe = Environment.ProcessPath;
        if (exe == null) throw new InvalidOperationException("Cannot determine this program's path.");
        System.Diagnostics.Process.Start(new System.Diagnostics.ProcessStartInfo(exe) { UseShellExecute = true });
        Log("Started a second instance. Open the IPC module there and exchange messages between the two programs.");
    }

    protected override void OnFormClosed(FormClosedEventArgs e)
    {
        StopPipeServer();
        StopTcpServer();
        _sharedMemory?.Dispose();
        _event?.Dispose();
        base.OnFormClosed(e);
    }
}
