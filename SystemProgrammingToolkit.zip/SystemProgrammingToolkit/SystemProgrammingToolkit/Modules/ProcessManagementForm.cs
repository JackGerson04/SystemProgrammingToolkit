using System.ComponentModel;
using System.Diagnostics;
using System.Runtime.InteropServices;
using SystemProgrammingToolkit.Common;
using SystemProgrammingToolkit.Native;

namespace SystemProgrammingToolkit.Modules;

/// <summary>
/// Module 1 - Process management.
/// Concepts: CreateProcess (Process.Start), TerminateProcess (Kill), graceful close (WM_CLOSE),
/// NtSuspendProcess / NtResumeProcess (P/Invoke), priority classes, enumerating processes,
/// redirected standard streams of a child process.
/// </summary>
public sealed class ProcessManagementForm : ModuleFormBase
{
    private readonly ListView _list = new();
    private readonly TextBox _txtPath = new() { Text = "notepad.exe", Width = 190 };
    private readonly TextBox _txtArgs = new() { Width = 150 };
    private readonly TextBox _txtFilter = new() { Width = 120 };
    private readonly TextBox _txtCmd = new() { Width = 420, Text = "cmd.exe /c ver & echo Hello from a child process" };
    private readonly ComboBox _cmbPriority = new() { DropDownStyle = ComboBoxStyle.DropDownList, Width = 110 };
    private readonly CheckBox _chkAuto = new() { Text = "Auto-refresh (2 s)", AutoSize = true, Margin = new Padding(8, 6, 3, 3) };
    private readonly System.Windows.Forms.Timer _timer = new() { Interval = 2000 };
    private readonly HashSet<int> _suspended = new();

    public ProcessManagementForm() : base(
        "Process Management",
        "Create, terminate, suspend, resume and inspect operating-system processes (System.Diagnostics + ntdll P/Invoke).",
        contentFills: true)
    {
        BuildContent();

        AddButton("Start Process", StartProcess);
        AddButton("Stop (Kill)", KillProcess);
        AddButton("Close Gracefully", CloseGracefully);
        AddButton("Pause (Suspend)", () => SuspendOrResume(true));
        AddButton("Resume", () => SuspendOrResume(false));
        NewRow();
        AddButton("List / Refresh", () => RefreshList(true));
        AddButton("Process Details", ShowDetails);
        AddButton("Set Priority", SetPriority);
        AddAsyncButton("Run && Capture Output", RunAndCaptureAsync);
        AddButton("This Process Info", ShowSelfInfo);

        _timer.Tick += (_, _) => RefreshList(false);
        _chkAuto.CheckedChanged += (_, _) => _timer.Enabled = _chkAuto.Checked;

        RefreshList(true);
    }

    private void BuildContent()
    {
        foreach (var p in Enum.GetValues<ProcessPriorityClass>()) _cmbPriority.Items.Add(p);
        _cmbPriority.SelectedItem = ProcessPriorityClass.Normal;

        _list.View = View.Details;
        _list.FullRowSelect = true;
        _list.GridLines = true;
        _list.MultiSelect = false;
        _list.HideSelection = false;
        _list.Dock = DockStyle.Fill;
        _list.Columns.Add("PID", 65);
        _list.Columns.Add("Name", 190);
        _list.Columns.Add("Status", 85);
        _list.Columns.Add("Threads", 70);
        _list.Columns.Add("Memory (MB)", 100);
        _list.Columns.Add("Priority", 100);
        _list.Columns.Add("Started", 150);
        _list.DoubleClick += (_, _) => { try { ShowDetails(); } catch (Exception ex) { LogError(ex); } };

        var bar = new FlowLayoutPanel { Dock = DockStyle.Fill, AutoSize = true };
        bar.Controls.AddRange(new Control[]
        {
            MakeLabel("Executable:"), _txtPath,
            MakeLabel("Arguments:"), _txtArgs,
            MakeLabel("Filter:"), _txtFilter,
            MakeLabel("Priority:"), _cmbPriority,
            _chkAuto
        });
        bar.SetFlowBreak(_chkAuto, true);
        bar.Controls.AddRange(new Control[] { MakeLabel("Capture command:"), _txtCmd });

        var grid = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 1, RowCount = 2 };
        grid.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
        grid.RowStyles.Add(new RowStyle(SizeType.AutoSize));
        grid.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
        grid.Controls.Add(bar, 0, 0);
        grid.Controls.Add(_list, 0, 1);
        ContentPanel.Controls.Add(grid);
    }

    // ---- LIST ---------------------------------------------------------------------------

    private void RefreshList(bool log)
    {
        int? selected = _list.SelectedItems.Count > 0 ? (int?)_list.SelectedItems[0].Tag : null;
        string filter = _txtFilter.Text.Trim();
        var rows = new List<(int Pid, string Name, string Status, int Threads, double Mb, string Prio, string Start)>();
        var livePids = new HashSet<int>();

        foreach (var p in Process.GetProcesses())
        {
            using (p)
            {
                livePids.Add(p.Id);
                if (filter.Length > 0 && !p.ProcessName.Contains(filter, StringComparison.OrdinalIgnoreCase)) continue;

                int threads = 0;
                string prio = "-", start = "-";
                try { threads = p.Threads.Count; } catch { }
                try { prio = p.PriorityClass.ToString(); } catch { prio = "(denied)"; }
                try { start = p.StartTime.ToString("yyyy-MM-dd HH:mm:ss"); } catch { start = "(denied)"; }

                rows.Add((p.Id, p.ProcessName, _suspended.Contains(p.Id) ? "Suspended" : "Running",
                          threads, p.WorkingSet64 / 1048576.0, prio, start));
            }
        }
        _suspended.RemoveWhere(pid => !livePids.Contains(pid));

        _list.BeginUpdate();
        _list.Items.Clear();
        foreach (var r in rows.OrderByDescending(r => r.Mb))
        {
            var item = new ListViewItem(new[]
            {
                r.Pid.ToString(), r.Name, r.Status, r.Threads.ToString(), r.Mb.ToString("N1"), r.Prio, r.Start
            }) { Tag = r.Pid };
            if (r.Status == "Suspended") item.ForeColor = Color.OrangeRed;
            _list.Items.Add(item);
            if (selected == r.Pid) item.Selected = true;
        }
        _list.EndUpdate();

        if (log) Log($"Listed {rows.Count} process(es){(filter.Length > 0 ? $" matching '{filter}'" : "")} (total running: {livePids.Count}).");
    }

    private void SelectPid(int pid)
    {
        foreach (ListViewItem item in _list.Items)
        {
            if ((int)item.Tag! == pid) { item.Selected = true; item.EnsureVisible(); return; }
        }
    }

    private int? GetSelectedPid()
    {
        if (_list.SelectedItems.Count == 0)
        {
            Log("Select a process in the list first.");
            return null;
        }
        return (int)_list.SelectedItems[0].Tag!;
    }

    // ---- START / STOP ------------------------------------------------------------------

    private void StartProcess()
    {
        string path = _txtPath.Text.Trim();
        if (path.Length == 0) { Log("Enter an executable name or path first."); return; }

        // UseShellExecute = true  -> ShellExecuteEx (also opens documents / URLs)
        using var p = Process.Start(new ProcessStartInfo(path, _txtArgs.Text) { UseShellExecute = true });
        if (p == null)
        {
            Log("Process.Start returned null (an existing instance handled the request).");
            return;
        }
        Log($"Started '{path}' -> PID {p.Id}");
        RefreshList(false);
        SelectPid(p.Id);
    }

    private void KillProcess()
    {
        if (GetSelectedPid() is not int pid) return;
        if (pid == Environment.ProcessId) { Log("Refusing to terminate this application."); return; }
        if (pid <= 4) { Log("Refusing to terminate a core system process."); return; }

        using var p = Process.GetProcessById(pid);
        string name = p.ProcessName;
        var answer = MessageBox.Show(this,
            $"Terminate '{name}' (PID {pid}) and its child processes?\nUnsaved data in that program will be lost.",
            "Confirm terminate", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
        if (answer != DialogResult.Yes) return;

        p.Kill(entireProcessTree: true);   // TerminateProcess
        bool exited = p.WaitForExit(3000);
        _suspended.Remove(pid);
        Log($"Killed '{name}' (PID {pid}). Exited: {exited}");
        RefreshList(false);
    }

    private void CloseGracefully()
    {
        if (GetSelectedPid() is not int pid) return;
        using var p = Process.GetProcessById(pid);
        bool sent = p.CloseMainWindow();    // posts WM_CLOSE to the main window
        Log(sent
            ? $"WM_CLOSE sent to '{p.ProcessName}' (PID {pid}); the program may still prompt to save."
            : $"'{p.ProcessName}' has no main window to close - use Stop (Kill) instead.");
    }

    // ---- PAUSE / RESUME ----------------------------------------------------------------

    private void SuspendOrResume(bool suspend)
    {
        if (GetSelectedPid() is not int pid) return;
        if (pid == Environment.ProcessId) { Log("Refusing to suspend this application."); return; }
        if (pid <= 4) { Log("Refusing to suspend a core system process."); return; }

        IntPtr handle = NativeMethods.OpenProcess(NativeMethods.PROCESS_SUSPEND_RESUME, false, pid);
        if (handle == IntPtr.Zero) throw new Win32Exception(Marshal.GetLastWin32Error());
        try
        {
            int status = suspend ? NativeMethods.NtSuspendProcess(handle) : NativeMethods.NtResumeProcess(handle);
            if (status != 0) throw new InvalidOperationException($"NTSTATUS 0x{status:X8}");
        }
        finally { NativeMethods.CloseHandle(handle); }

        if (suspend) _suspended.Add(pid); else _suspended.Remove(pid);
        Log($"{(suspend ? "Suspended" : "Resumed")} PID {pid} via {(suspend ? "NtSuspendProcess" : "NtResumeProcess")}.");
        RefreshList(false);
    }

    // ---- PRIORITY / DETAILS ------------------------------------------------------------

    private void SetPriority()
    {
        if (GetSelectedPid() is not int pid) return;
        var cls = (ProcessPriorityClass)_cmbPriority.SelectedItem!;
        using var p = Process.GetProcessById(pid);
        var old = p.PriorityClass;
        p.PriorityClass = cls;
        Log($"PID {pid} ({p.ProcessName}): priority {old} -> {cls}");
        RefreshList(false);
    }

    private void ShowDetails()
    {
        if (GetSelectedPid() is not int pid) return;
        using var p = Process.GetProcessById(pid);
        Log($"--- Details: {p.ProcessName} (PID {pid}) ---");
        Describe(p);
        try
        {
            var modules = p.Modules.Cast<ProcessModule>().Take(8).ToList();
            Log($"  Loaded modules (first {modules.Count} of {p.Modules.Count}):");
            foreach (var m in modules) Log($"    {m.ModuleName}  ({FormatBytes(m.ModuleMemorySize)})");
        }
        catch (Exception ex) { Log($"  Modules: <{ex.GetType().Name}: {ex.Message}>"); }
    }

    private void ShowSelfInfo()
    {
        using var p = Process.GetCurrentProcess();
        Log($"--- This application: {p.ProcessName} (PID {p.Id}) ---");
        Describe(p);
        Log($"  Command line: {Environment.CommandLine}");
        Log($"  64-bit process: {Environment.Is64BitProcess}, 64-bit OS: {Environment.Is64BitOperatingSystem}");
    }

    private void Describe(Process p)
    {
        void Try(string label, Func<string> value)
        {
            try { Log($"  {label}: {value()}"); }
            catch (Exception ex) { Log($"  {label}: <{ex.GetType().Name}>"); }
        }
        Try("Started", () => p.StartTime.ToString("F"));
        Try("CPU time", () => p.TotalProcessorTime.ToString());
        Try("Threads", () => p.Threads.Count.ToString());
        Try("Handles", () => p.HandleCount.ToString());
        Try("Working set", () => FormatBytes(p.WorkingSet64));
        Try("Peak working set", () => FormatBytes(p.PeakWorkingSet64));
        Try("Private memory", () => FormatBytes(p.PrivateMemorySize64));
        Try("Priority", () => p.PriorityClass.ToString());
        Try("Executable", () => p.MainModule?.FileName ?? "n/a");
        Try("Main window title", () => string.IsNullOrEmpty(p.MainWindowTitle) ? "(none)" : p.MainWindowTitle);
    }

    // ---- CHILD PROCESS WITH REDIRECTED STREAMS ----------------------------------------

    private async Task RunAndCaptureAsync()
    {
        string cmd = _txtCmd.Text.Trim();
        if (cmd.Length == 0) { Log("Enter a command line to run."); return; }

        int space = cmd.IndexOf(' ');
        string file = space < 0 ? cmd : cmd[..space];
        string args = space < 0 ? "" : cmd[(space + 1)..];

        var psi = new ProcessStartInfo(file, args)
        {
            UseShellExecute = false,          // required for redirection (CreateProcess + pipes)
            RedirectStandardOutput = true,
            RedirectStandardError = true,
            CreateNoWindow = true
        };

        using var p = new Process { StartInfo = psi };
        p.Start();
        Log($"Child process PID {p.Id} started: {cmd}");

        var stdout = p.StandardOutput.ReadToEndAsync();
        var stderr = p.StandardError.ReadToEndAsync();

        using var cts = new CancellationTokenSource(TimeSpan.FromSeconds(15));
        try
        {
            await p.WaitForExitAsync(cts.Token);
        }
        catch (OperationCanceledException)
        {
            p.Kill(true);
            Log("Child process timed out after 15 s and was killed.");
            return;
        }

        foreach (var line in (await stdout).Split(new[] { '\r', '\n' }, StringSplitOptions.RemoveEmptyEntries))
            Log("  stdout> " + line);
        foreach (var line in (await stderr).Split(new[] { '\r', '\n' }, StringSplitOptions.RemoveEmptyEntries))
            Log("  stderr> " + line);
        Log($"Child exited with code {p.ExitCode}.");
    }

    protected override void OnFormClosed(FormClosedEventArgs e)
    {
        _timer.Dispose();
        base.OnFormClosed(e);
    }
}
