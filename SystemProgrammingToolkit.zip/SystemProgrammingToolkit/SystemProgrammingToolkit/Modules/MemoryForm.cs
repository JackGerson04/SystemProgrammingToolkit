using System.ComponentModel;
using System.Diagnostics;
using System.IO.MemoryMappedFiles;
using System.Runtime;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using SystemProgrammingToolkit.Common;
using SystemProgrammingToolkit.Native;

namespace SystemProgrammingToolkit.Modules;

/// <summary>
/// Module 4 - Memory management.
/// Concepts: physical vs virtual memory, working set, managed heap + garbage collector (generations, LOH),
/// unmanaged heap (HeapAlloc via AllocHGlobal), VirtualAlloc reserve/commit/decommit/release,
/// memory-mapped files, stack vs heap allocation.
/// </summary>
public sealed class MemoryForm : ModuleFormBase
{
    private readonly NumericUpDown _numSize = new() { Minimum = 1, Maximum = 1024, Value = 50, Width = 70 };
    private readonly ProgressBar _loadBar = new() { Width = 220, Height = 18, Margin = new Padding(6, 8, 3, 3) };
    private readonly Label _loadLabel = new() { AutoSize = true, Margin = new Padding(6, 8, 3, 0) };
    private readonly System.Windows.Forms.Timer _timer = new() { Interval = 1000 };
    private readonly List<byte[]> _managedBlocks = new();
    private readonly List<(IntPtr Ptr, long Size)> _unmanagedBlocks = new();

    public MemoryForm() : base(
        "Memory Management",
        "Inspect system memory and allocate, touch and free memory through the GC, the unmanaged heap and the Win32 virtual-memory API.",
        contentHeight: 44)
    {
        var bar = new FlowLayoutPanel { Dock = DockStyle.Fill };
        bar.Controls.AddRange(new Control[] { MakeLabel("Block size (MB):"), _numSize, MakeLabel("System RAM in use:"), _loadBar, _loadLabel });
        ContentPanel.Controls.Add(bar);

        AddButton("System Memory", ShowSystemMemory);
        AddButton("System Info (page size)", ShowSystemInfo);
        AddButton("This Process Memory", ShowProcessMemory);
        NewRow();
        AddButton("Allocate Managed", AllocateManaged);
        AddButton("Free Managed + GC", FreeManaged);
        AddButton("Allocate Unmanaged", AllocateUnmanaged);
        AddButton("Free Unmanaged", FreeUnmanaged);
        NewRow();
        AddButton("VirtualAlloc Demo", VirtualMemoryDemo);
        AddButton("Memory-Mapped File", MemoryMappedDemo);
        AddButton("Garbage Collector Demo", GcDemo);
        AddButton("Stack vs Heap", StackVsHeap);

        _timer.Tick += (_, _) => UpdateLoad();
        _timer.Start();
        UpdateLoad();
    }

    private void UpdateLoad()
    {
        var status = GetMemoryStatus();
        _loadBar.Value = (int)Math.Clamp(status.dwMemoryLoad, 0, 100);
        _loadLabel.Text = $"{status.dwMemoryLoad}%  ({FormatBytes(status.ullAvailPhys)} free)";
    }

    private static NativeMethods.MEMORYSTATUSEX GetMemoryStatus()
    {
        var status = new NativeMethods.MEMORYSTATUSEX { dwLength = (uint)Marshal.SizeOf<NativeMethods.MEMORYSTATUSEX>() };
        if (!NativeMethods.GlobalMemoryStatusEx(ref status)) throw new Win32Exception(Marshal.GetLastWin32Error());
        return status;
    }

    private static long WorkingSet()
    {
        using var p = Process.GetCurrentProcess();
        return p.WorkingSet64;
    }

    private long SelectedBytes => (long)_numSize.Value * 1024 * 1024;

    // ---- information ---------------------------------------------------------------------

    private void ShowSystemMemory()
    {
        var s = GetMemoryStatus();
        Log("--- GlobalMemoryStatusEx ---");
        Log($"  Memory load        : {s.dwMemoryLoad}%");
        Log($"  Physical (RAM)     : {FormatBytes(s.ullTotalPhys)} total, {FormatBytes(s.ullAvailPhys)} available");
        Log($"  Commit limit (RAM+pagefile): {FormatBytes(s.ullTotalPageFile)} total, {FormatBytes(s.ullAvailPageFile)} available");
        Log($"  Virtual address space (per process): {FormatBytes(s.ullTotalVirtual)} total, {FormatBytes(s.ullAvailVirtual)} available");
    }

    private void ShowSystemInfo()
    {
        NativeMethods.GetSystemInfo(out var si);
        Log("--- GetSystemInfo ---");
        Log($"  Page size              : {si.dwPageSize:N0} bytes");
        Log($"  Allocation granularity : {si.dwAllocationGranularity / 1024} KB (VirtualAlloc reservations align to this)");
        Log($"  Logical processors     : {si.dwNumberOfProcessors}");
        Log($"  Lowest / highest user address: 0x{si.lpMinimumApplicationAddress.ToInt64():X} / 0x{si.lpMaximumApplicationAddress.ToInt64():X}");
    }

    private void ShowProcessMemory()
    {
        using var p = Process.GetCurrentProcess();
        var gc = GC.GetGCMemoryInfo();
        Log("--- This process ---");
        Log($"  Working set (physical RAM now) : {FormatBytes(p.WorkingSet64)}   (peak {FormatBytes(p.PeakWorkingSet64)})");
        Log($"  Private bytes (committed)      : {FormatBytes(p.PrivateMemorySize64)}");
        Log($"  Virtual size (reserved+mapped) : {FormatBytes(p.VirtualMemorySize64)}");
        Log($"  Managed heap (GC.GetTotalMemory): {FormatBytes(GC.GetTotalMemory(false))}");
        Log($"  GC heap size / committed       : {FormatBytes(gc.HeapSizeBytes)} / {FormatBytes(gc.TotalCommittedBytes)}");
        Log($"  Collections gen0/gen1/gen2     : {GC.CollectionCount(0)}/{GC.CollectionCount(1)}/{GC.CollectionCount(2)}");
    }

    // ---- managed heap ----------------------------------------------------------------------

    private void AllocateManaged()
    {
        long before = WorkingSet();
        var block = new byte[SelectedBytes];
        Array.Fill(block, (byte)0xAB);          // touch every page so the OS really commits RAM
        _managedBlocks.Add(block);
        Log($"Allocated managed byte[{FormatBytes(block.Length)}] (LOH object, generation {GC.GetGeneration(block)}). " +
            $"Working set {FormatBytes(before)} -> {FormatBytes(WorkingSet())}. Blocks held: {_managedBlocks.Count}");
    }

    private void FreeManaged()
    {
        int count = _managedBlocks.Count;
        long before = WorkingSet();
        _managedBlocks.Clear();                 // drop the references: blocks become unreachable
        GC.Collect(2, GCCollectionMode.Forced, blocking: true, compacting: true);
        GC.WaitForPendingFinalizers();
        Log($"Released {count} managed block(s) and forced a full GC. Working set {FormatBytes(before)} -> {FormatBytes(WorkingSet())}");
    }

    // ---- unmanaged heap ------------------------------------------------------------------

    private void AllocateUnmanaged()
    {
        long size = SelectedBytes;
        long before = WorkingSet();
        IntPtr ptr = Marshal.AllocHGlobal((IntPtr)size);   // native heap, invisible to the GC
        for (long offset = 0; offset < size; offset += 4096)
            Marshal.WriteByte(ptr, (int)offset, 0xCD);     // touch one byte per 4 KB page
        _unmanagedBlocks.Add((ptr, size));
        Log($"AllocHGlobal({FormatBytes(size)}) -> 0x{ptr.ToInt64():X}. Working set {FormatBytes(before)} -> {FormatBytes(WorkingSet())}. " +
            "The GC does NOT manage this memory: you must free it yourself.");
    }

    private void FreeUnmanaged()
    {
        if (_unmanagedBlocks.Count == 0) { Log("No unmanaged blocks allocated."); return; }
        long before = WorkingSet();
        foreach (var (ptr, _) in _unmanagedBlocks) Marshal.FreeHGlobal(ptr);
        int count = _unmanagedBlocks.Count;
        _unmanagedBlocks.Clear();
        Log($"FreeHGlobal on {count} block(s). Working set {FormatBytes(before)} -> {FormatBytes(WorkingSet())}");
    }

    // ---- Win32 virtual memory --------------------------------------------------------------

    private void VirtualMemoryDemo()
    {
        NativeMethods.GetSystemInfo(out var si);
        var reserveSize = (UIntPtr)(16u * 1024 * 1024);
        uint commitBytes = si.dwPageSize * 16;

        IntPtr baseAddress = NativeMethods.VirtualAlloc(IntPtr.Zero, reserveSize, NativeMethods.MEM_RESERVE, NativeMethods.PAGE_NOACCESS);
        if (baseAddress == IntPtr.Zero) throw new Win32Exception(Marshal.GetLastWin32Error());

        try
        {
            Log($"1. RESERVE : 16 MB of address space at 0x{baseAddress.ToInt64():X} (no RAM used; access would crash).");

            IntPtr committed = NativeMethods.VirtualAlloc(baseAddress, (UIntPtr)commitBytes, NativeMethods.MEM_COMMIT, NativeMethods.PAGE_READWRITE);
            if (committed == IntPtr.Zero) throw new Win32Exception(Marshal.GetLastWin32Error());
            Log($"2. COMMIT  : {commitBytes / 1024} KB (16 pages of {si.dwPageSize} bytes) made read/write.");

            for (int page = 0; page < 16; page++)
                Marshal.WriteInt32(committed, page * (int)si.dwPageSize, 0x1000 + page);
            long sum = 0;
            for (int page = 0; page < 16; page++)
                sum += Marshal.ReadInt32(committed, page * (int)si.dwPageSize);
            Log($"3. USE     : wrote a marker into each page and read them back (sum = {sum}).");

            if (!NativeMethods.VirtualFree(baseAddress, (UIntPtr)commitBytes, NativeMethods.MEM_DECOMMIT))
                throw new Win32Exception(Marshal.GetLastWin32Error());
            Log("4. DECOMMIT: pages returned to the OS; the address range stays reserved.");
        }
        finally
        {
            if (NativeMethods.VirtualFree(baseAddress, UIntPtr.Zero, NativeMethods.MEM_RELEASE))
                Log("5. RELEASE : address space given back completely.");
        }
    }

    private void MemoryMappedDemo()
    {
        string dir = Path.Combine(Path.GetTempPath(), "SystemProgrammingToolkit");
        Directory.CreateDirectory(dir);
        string path = Path.Combine(dir, "mmf-demo.bin");
        const int capacity = 1 << 20;

        using var fs = new FileStream(path, FileMode.Create, FileAccess.ReadWrite, FileShare.ReadWrite);
        fs.SetLength(capacity);
        using var mmf = MemoryMappedFile.CreateFromFile(fs, null, capacity, MemoryMappedFileAccess.ReadWrite, HandleInheritability.None, leaveOpen: true);
        using var view = mmf.CreateViewAccessor(0, 4096);

        view.Write(0, 42);
        view.Write(8, Math.PI);
        view.Flush();
        Log($"Mapped '{Path.GetFileName(path)}' ({FormatBytes(capacity)}) into memory and wrote through a 4 KB view (no Write() calls on the file).");
        Log($"Read back via the view: int = {view.ReadInt32(0)}, double = {view.ReadDouble(8):F5}");
        Log("The OS pages data to/from disk on demand; the same mechanism backs executables, DLLs and shared memory.");
    }

    // ---- garbage collector -----------------------------------------------------------------

    private void GcDemo()
    {
        Log($"--- GC: max generation {GC.MaxGeneration}, server GC = {GCSettings.IsServerGC}, latency mode = {GCSettings.LatencyMode} ---");

        var obj = new object();
        Log($"New object starts in generation {GC.GetGeneration(obj)}");
        GC.Collect(0);
        Log($"After a gen0 collection it survived -> generation {GC.GetGeneration(obj)}");
        GC.Collect(1);
        Log($"After a gen1 collection it survived -> generation {GC.GetGeneration(obj)}");

        var small = new byte[1000];
        var large = new byte[100_000];
        Log($"byte[1000] is in gen {GC.GetGeneration(small)}; byte[100000] is in gen {GC.GetGeneration(large)} (Large Object Heap, >= 85,000 bytes)");

        long before = GC.GetTotalMemory(false);
        var temp = new List<byte[]>();
        for (int i = 0; i < 200; i++) temp.Add(new byte[100_000]);
        long during = GC.GetTotalMemory(false);
        temp.Clear();
        long after = GC.GetTotalMemory(true);   // forces a full collection
        Log($"Managed heap: before {FormatBytes(before)}, after allocating 200 x 100 KB {FormatBytes(during)}, after release + GC {FormatBytes(after)}");

        var weak = CreateWeakReference();
        Log($"WeakReference alive before GC: {weak.IsAlive}");
        GC.Collect();
        GC.WaitForPendingFinalizers();
        Log($"WeakReference alive after GC : {weak.IsAlive}  (a weak reference does not keep its target alive)");
        Log($"Collections so far: gen0={GC.CollectionCount(0)}, gen1={GC.CollectionCount(1)}, gen2={GC.CollectionCount(2)}");

        GC.KeepAlive(obj);
        GC.KeepAlive(small);
        GC.KeepAlive(large);
    }

    [MethodImpl(MethodImplOptions.NoInlining)]
    private static WeakReference CreateWeakReference() => new(new byte[10_000]);

    // ---- stack vs heap ---------------------------------------------------------------------

    private void StackVsHeap()
    {
        const int iterations = 100_000;

        long start = GC.GetAllocatedBytesForCurrentThread();
        int sum = 0;
        for (int i = 0; i < iterations; i++) sum += UseHeapBuffer();
        long heapBytes = GC.GetAllocatedBytesForCurrentThread() - start;

        start = GC.GetAllocatedBytesForCurrentThread();
        for (int i = 0; i < iterations; i++) sum += UseStackBuffer();
        long stackBytes = GC.GetAllocatedBytesForCurrentThread() - start;

        Log($"{iterations:N0} x 256-byte buffer: new byte[256] allocated {FormatBytes(heapBytes)} on the heap; stackalloc allocated {FormatBytes(stackBytes)} (checksum {sum}).");
        Log("Stack memory is freed automatically when the method returns, with no garbage-collector work.");
    }

    private static byte[]? _escape;   // storing the array here stops the JIT from stack-allocating it

    private static int UseHeapBuffer()
    {
        var buffer = new byte[256];
        buffer.AsSpan().Fill(1);
        _escape = buffer;
        return buffer[10];
    }

    private static int UseStackBuffer()
    {
        Span<byte> buffer = stackalloc byte[256];
        buffer.Fill(1);
        return buffer[10];
    }

    protected override void OnFormClosed(FormClosedEventArgs e)
    {
        _timer.Dispose();
        // Don't leak native memory if the user forgot to press "Free Unmanaged".
        foreach (var (ptr, _) in _unmanagedBlocks) Marshal.FreeHGlobal(ptr);
        _unmanagedBlocks.Clear();
        _managedBlocks.Clear();
        base.OnFormClosed(e);
    }
}
