using System.Diagnostics;
using System.Text;
using SystemProgrammingToolkit.Common;

namespace SystemProgrammingToolkit.Modules;

/// <summary>
/// Module 3 - File system and I/O.
/// Concepts: file handles (CreateFile / ReadFile / WriteFile under the hood), text and binary I/O,
/// file attributes and metadata, directory enumeration, buffering, sharing modes (file locking),
/// change notifications (ReadDirectoryChangesW via FileSystemWatcher), drive information.
/// All work happens inside a private sandbox folder in %TEMP%.
/// </summary>
public sealed class FileSystemForm : ModuleFormBase
{
    private static readonly string WorkDir = Path.Combine(Path.GetTempPath(), "SystemProgrammingToolkit");

    private readonly TextBox _txtFile = new() { Text = "sample.txt", Width = 180 };
    private readonly TextBox _txtContent = new() { Text = "Hello from the System Programming Toolkit!", Width = 420 };
    private Button _btnWatch = null!;
    private FileSystemWatcher? _watcher;

    public FileSystemForm() : base(
        "File System & I/O",
        "Work with files, directories and file handles. Everything happens inside a sandbox folder in your TEMP directory.",
        contentHeight: 76)
    {
        Directory.CreateDirectory(WorkDir);

        var bar = new FlowLayoutPanel { Dock = DockStyle.Fill };
        bar.Controls.AddRange(new Control[] { MakeLabel("File name:"), _txtFile, MakeLabel("Content:"), _txtContent });
        bar.SetFlowBreak(_txtContent, true);
        bar.Controls.Add(new Label { Text = $"Sandbox folder: {WorkDir}", AutoSize = true, ForeColor = Color.DimGray, Margin = new Padding(6, 4, 3, 0) });
        ContentPanel.Controls.Add(bar);

        AddButton("Create / Overwrite", CreateFile);
        AddButton("Read", ReadFile);
        AddButton("Append Line", AppendLine);
        AddButton("Copy", CopyFile);
        AddButton("Move to \\archive", MoveFile);
        AddButton("Delete", DeleteFile);
        NewRow();
        AddButton("File Info", ShowFileInfo);
        AddButton("Toggle Read-Only", ToggleReadOnly);
        AddButton("Create Sample Tree", CreateSampleTree);
        AddButton("List Directory", ListDirectory);
        AddButton("Drive Info", ShowDrives);
        AddButton("Open Folder", () => Process.Start(new ProcessStartInfo(WorkDir) { UseShellExecute = true }));
        NewRow();
        AddButton("Binary I/O", BinaryDemo);
        AddAsyncButton("Buffering Benchmark", BenchmarkAsync);
        AddButton("File Locking Demo", LockingDemo);
        _btnWatch = AddButton("Start Watcher", ToggleWatcher);
        AddButton("Clean Sandbox", CleanSandbox);
    }

    private string GetPath()
    {
        string name = Path.GetFileName(_txtFile.Text.Trim());   // strips any directory part (no path traversal)
        if (string.IsNullOrEmpty(name)) throw new InvalidOperationException("Enter a file name.");
        return Path.Combine(WorkDir, name);
    }

    private void CreateFile()
    {
        string path = GetPath();
        File.WriteAllText(path, _txtContent.Text + Environment.NewLine, Encoding.UTF8);
        Log($"Created/overwrote '{path}' ({new FileInfo(path).Length} bytes)");
    }

    private void ReadFile()
    {
        string path = GetPath();
        using var stream = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.Read);
        using var reader = new StreamReader(stream, Encoding.UTF8);
        string text = reader.ReadToEnd();
        Log($"Read {stream.Length} bytes from '{Path.GetFileName(path)}':");
        foreach (var line in text.Split(new[] { '\r', '\n' }, StringSplitOptions.RemoveEmptyEntries))
            Log("  | " + line);
    }

    private void AppendLine()
    {
        string path = GetPath();
        File.AppendAllText(path, $"{DateTime.Now:O} - {_txtContent.Text}{Environment.NewLine}", Encoding.UTF8);
        Log($"Appended a line to '{Path.GetFileName(path)}' (now {new FileInfo(path).Length} bytes)");
    }

    private void CopyFile()
    {
        string src = GetPath();
        string dst = src + ".copy";
        File.Copy(src, dst, overwrite: true);
        Log($"Copied '{Path.GetFileName(src)}' -> '{Path.GetFileName(dst)}'");
    }

    private void MoveFile()
    {
        string src = GetPath();
        string archive = Path.Combine(WorkDir, "archive");
        Directory.CreateDirectory(archive);
        string dst = Path.Combine(archive, Path.GetFileName(src));
        File.Move(src, dst, overwrite: true);
        Log($"Moved to '{dst}'");
    }

    private void DeleteFile()
    {
        string path = GetPath();
        if (!File.Exists(path)) { Log($"'{Path.GetFileName(path)}' does not exist."); return; }
        File.SetAttributes(path, FileAttributes.Normal);   // clear read-only so delete succeeds
        File.Delete(path);
        Log($"Deleted '{Path.GetFileName(path)}'");
    }

    private void ShowFileInfo()
    {
        var fi = new FileInfo(GetPath());
        if (!fi.Exists) { Log("File does not exist - create it first."); return; }
        Log($"--- {fi.Name} ---");
        Log($"  Full path  : {fi.FullName}");
        Log($"  Size       : {fi.Length} bytes");
        Log($"  Attributes : {fi.Attributes}");
        Log($"  Created    : {fi.CreationTime:F}");
        Log($"  Modified   : {fi.LastWriteTime:F}");
        Log($"  Accessed   : {fi.LastAccessTime:F}");
        Log($"  Read-only  : {fi.IsReadOnly}");
    }

    private void ToggleReadOnly()
    {
        var fi = new FileInfo(GetPath());
        if (!fi.Exists) { Log("File does not exist - create it first."); return; }
        fi.IsReadOnly = !fi.IsReadOnly;
        Log($"'{fi.Name}' read-only attribute is now {fi.IsReadOnly}. Try 'Create / Overwrite' to see the OS refuse the write.");
    }

    private void CreateSampleTree()
    {
        foreach (var dir in new[] { "docs", @"docs\images", "src", @"src\lib" })
            Directory.CreateDirectory(Path.Combine(WorkDir, dir));
        File.WriteAllText(Path.Combine(WorkDir, @"docs\readme.txt"), "Documentation");
        File.WriteAllText(Path.Combine(WorkDir, @"docs\images\logo.txt"), "logo placeholder");
        File.WriteAllText(Path.Combine(WorkDir, @"src\main.cs"), "// main");
        File.WriteAllText(Path.Combine(WorkDir, @"src\lib\util.cs"), "// util");
        Log("Created sample folders: docs, docs\\images, src, src\\lib (with files). Use 'List Directory'.");
    }

    private void ListDirectory()
    {
        Log($"--- {WorkDir} ---");
        int files = 0, dirs = 0;
        long bytes = 0;
        foreach (var entry in Directory.EnumerateFileSystemEntries(WorkDir, "*", SearchOption.AllDirectories).OrderBy(e => e))
        {
            string rel = Path.GetRelativePath(WorkDir, entry);
            int depth = rel.Count(c => c == Path.DirectorySeparatorChar);
            string indent = new string(' ', depth * 2);
            if (Directory.Exists(entry))
            {
                dirs++;
                Log($"  {indent}[{Path.GetFileName(entry)}]");
            }
            else
            {
                files++;
                long len = new FileInfo(entry).Length;
                bytes += len;
                Log($"  {indent}{Path.GetFileName(entry)}  ({len:N0} bytes)");
            }
        }
        Log($"Total: {dirs} folder(s), {files} file(s), {FormatBytes(bytes)}");
    }

    private void ShowDrives()
    {
        foreach (var d in DriveInfo.GetDrives())
        {
            if (!d.IsReady) { Log($"  {d.Name}  {d.DriveType}  (not ready)"); continue; }
            Log($"  {d.Name}  {d.DriveType,-10} {d.DriveFormat,-6} total {FormatBytes(d.TotalSize),-10} free {FormatBytes(d.AvailableFreeSpace)}");
        }
    }

    private void BinaryDemo()
    {
        string path = Path.Combine(WorkDir, "records.bin");
        using (var fs = new FileStream(path, FileMode.Create, FileAccess.Write, FileShare.None))
        using (var bw = new BinaryWriter(fs, Encoding.UTF8))
        {
            for (int i = 1; i <= 5; i++)
            {
                bw.Write(i);                  // 4 bytes
                bw.Write(i * 3.14159);        // 8 bytes
                bw.Write($"Record-{i}");      // length-prefixed UTF-8 string
            }
        }
        Log($"Wrote 5 binary records to records.bin ({new FileInfo(path).Length} bytes).");

        using var input = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.Read);
        using var br = new BinaryReader(input, Encoding.UTF8);
        while (input.Position < input.Length)
        {
            int id = br.ReadInt32();
            double value = br.ReadDouble();
            string name = br.ReadString();
            Log($"  read: id={id}, value={value:F3}, name={name}");
        }
    }

    private async Task BenchmarkAsync()
    {
        string path = Path.Combine(WorkDir, "benchmark.tmp");
        const int totalBytes = 8 * 1024 * 1024;
        const int chunk = 512;
        Log($"Writing {FormatBytes(totalBytes)} in {chunk}-byte chunks with different FileStream buffer sizes...");

        foreach (int bufferSize in new[] { 1, 4096, 65536, 1 << 20 })   // 1 = buffering disabled
        {
            long ms = await Task.Run(() =>
            {
                var data = new byte[chunk];
                var sw = Stopwatch.StartNew();
                using (var fs = new FileStream(path, FileMode.Create, FileAccess.Write, FileShare.None, bufferSize))
                {
                    for (int written = 0; written < totalBytes; written += chunk) fs.Write(data, 0, chunk);
                }
                return sw.ElapsedMilliseconds;
            });
            Log($"  buffer {(bufferSize == 1 ? "none" : FormatBytes(bufferSize)),8}: {ms} ms  ({totalBytes / chunk:N0} write calls)");
        }
        File.Delete(path);
        Log("Larger buffers batch many small writes into fewer system calls.");
    }

    private void LockingDemo()
    {
        string path = GetPath();
        if (!File.Exists(path)) File.WriteAllText(path, "lock test");

        using var first = new FileStream(path, FileMode.Open, FileAccess.ReadWrite, FileShare.None);
        Log($"Handle #1 opened '{Path.GetFileName(path)}' with FileShare.None (exclusive).");
        try
        {
            using var second = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.Read);
            Log("Handle #2 opened successfully (unexpected).");
        }
        catch (IOException ex)
        {
            Log($"Handle #2 was refused by the OS (sharing violation): {ex.Message}");
        }
        Log("Handle #1 is closed when this method ends; the file is free again.");
    }

    private void ToggleWatcher()
    {
        if (_watcher == null)
        {
            _watcher = new FileSystemWatcher(WorkDir)
            {
                IncludeSubdirectories = true,
                NotifyFilter = NotifyFilters.FileName | NotifyFilters.DirectoryName | NotifyFilters.LastWrite | NotifyFilters.Size,
            };
            _watcher.Created += (_, e) => Log($"[Watcher] Created : {e.Name}");
            _watcher.Changed += (_, e) => Log($"[Watcher] Changed : {e.Name}");
            _watcher.Deleted += (_, e) => Log($"[Watcher] Deleted : {e.Name}");
            _watcher.Renamed += (_, e) => Log($"[Watcher] Renamed : {e.OldName} -> {e.Name}");
            _watcher.Error += (_, e) => Log($"[Watcher] Error   : {e.GetException().Message}");
            _watcher.EnableRaisingEvents = true;
            _btnWatch.Text = "Stop Watcher";
            Log("Watcher started. Create, edit, copy or delete files (here or in Explorer) and watch the log.");
        }
        else
        {
            StopWatcher();
            Log("Watcher stopped.");
        }
    }

    private void StopWatcher()
    {
        if (_watcher == null) return;
        _watcher.EnableRaisingEvents = false;
        _watcher.Dispose();
        _watcher = null;
        _btnWatch.Text = "Start Watcher";
    }

    private void CleanSandbox()
    {
        foreach (var file in Directory.EnumerateFiles(WorkDir, "*", SearchOption.AllDirectories))
            File.SetAttributes(file, FileAttributes.Normal);
        foreach (var file in Directory.GetFiles(WorkDir)) File.Delete(file);
        foreach (var dir in Directory.GetDirectories(WorkDir)) Directory.Delete(dir, recursive: true);
        Log("Sandbox folder emptied.");
    }

    protected override void OnFormClosed(FormClosedEventArgs e)
    {
        StopWatcher();
        base.OnFormClosed(e);
    }
}
