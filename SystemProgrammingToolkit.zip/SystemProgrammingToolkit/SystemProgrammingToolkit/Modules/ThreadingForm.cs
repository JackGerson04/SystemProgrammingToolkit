using System.Collections.Concurrent;
using System.Diagnostics;
using SystemProgrammingToolkit.Common;
using SystemProgrammingToolkit.Native;

namespace SystemProgrammingToolkit.Modules;

/// <summary>
/// Module 2 - Threads and synchronization.
/// Concepts: thread creation (managed vs OS thread ids), race conditions, lock/Monitor,
/// Interlocked (atomic CPU instructions), named Mutex (kernel object), Semaphore,
/// producer-consumer queue, thread pool + Parallel.For, deadlock avoidance with timeouts.
/// </summary>
public sealed class ThreadingForm : ModuleFormBase
{
    private readonly NumericUpDown _numThreads = new() { Minimum = 2, Maximum = 64, Value = 4, Width = 60 };
    private readonly NumericUpDown _numIterations = new() { Minimum = 1000, Maximum = 5_000_000, Value = 200_000, Increment = 50_000, Width = 100 };
    private readonly object _lockObject = new();
    private int _counter;
    private int _semaphoreCurrent;
    private int _semaphoreMax;

    public ThreadingForm() : base(
        "Threads & Synchronization",
        "Create threads and see what happens when they share data - with and without synchronization primitives.",
        contentHeight: 44)
    {
        var bar = new FlowLayoutPanel { Dock = DockStyle.Fill };
        bar.Controls.AddRange(new Control[]
        {
            MakeLabel("Worker threads:"), _numThreads,
            MakeLabel("Iterations per thread:"), _numIterations
        });
        ContentPanel.Controls.Add(bar);

        AddAsyncButton("Create Threads", CreateThreadsAsync);
        AddAsyncButton("Thread Pool + Parallel.For", ParallelDemoAsync);
        NewRow();
        AddAsyncButton("Race Condition (no lock)", () => RunCounterDemoAsync("No synchronization", () => _counter++));
        AddAsyncButton("Fix: lock / Monitor", () => RunCounterDemoAsync("lock statement", () => { lock (_lockObject) { _counter++; } }));
        AddAsyncButton("Fix: Interlocked", () => RunCounterDemoAsync("Interlocked.Increment", () => Interlocked.Increment(ref _counter)));
        NewRow();
        AddAsyncButton("Named Mutex", MutexDemoAsync);
        AddAsyncButton("Semaphore (limit 3)", SemaphoreDemoAsync);
        AddAsyncButton("Producer / Consumer", ProducerConsumerAsync);
        AddAsyncButton("Deadlock + Avoidance", DeadlockDemoAsync);
    }

    private async Task CreateThreadsAsync()
    {
        int n = (int)_numThreads.Value;
        Log($"UI thread: managed id {Environment.CurrentManagedThreadId}, OS thread id {NativeMethods.GetCurrentThreadId()}");

        var threads = new List<Thread>();
        for (int i = 0; i < n; i++)
        {
            int id = i;
            var t = new Thread(() =>
            {
                Log($"  Worker {id}: managed id {Environment.CurrentManagedThreadId}, OS thread id {NativeMethods.GetCurrentThreadId()}, background={Thread.CurrentThread.IsBackground}");
                Thread.Sleep(300 + id * 60);
                Log($"  Worker {id}: finished");
            })
            { IsBackground = true, Name = $"Worker-{id}" };
            threads.Add(t);
            t.Start();
        }

        await Task.Run(() => threads.ForEach(t => t.Join()));
        Log("All worker threads joined.");
    }

    private async Task RunCounterDemoAsync(string label, Action increment)
    {
        int n = (int)_numThreads.Value;
        int iterations = (int)_numIterations.Value;
        _counter = 0;

        var sw = Stopwatch.StartNew();
        await Task.Run(() =>
        {
            var threads = Enumerable.Range(0, n)
                .Select(_ => new Thread(() => { for (int i = 0; i < iterations; i++) increment(); }))
                .ToList();
            threads.ForEach(t => t.Start());
            threads.ForEach(t => t.Join());
        });
        sw.Stop();

        long expected = (long)n * iterations;
        long actual = _counter;
        Log($"{label}: expected {expected:N0}, actual {actual:N0}, lost updates {expected - actual:N0}, time {sw.ElapsedMilliseconds} ms" +
            (expected == actual ? "  [correct]" : "  [RACE CONDITION]"));
    }

    private async Task MutexDemoAsync()
    {
        const string name = @"Local\SysProgToolkit.Demo.Mutex";
        Log($"A named Mutex is a kernel object ('{name}'); it works across threads AND processes.");

        await Task.Run(() =>
        {
            var holder = new Thread(() =>
            {
                using var m = new Mutex(false, name);
                m.WaitOne();
                Log("  Thread A: acquired the mutex, working for 2 s...");
                Thread.Sleep(2000);
                m.ReleaseMutex();
                Log("  Thread A: released the mutex");
            });

            var waiter = new Thread(() =>
            {
                Thread.Sleep(300);
                using var m = new Mutex(false, name);
                Log("  Thread B: trying to acquire with a 500 ms timeout...");
                if (m.WaitOne(500))
                {
                    Log("  Thread B: acquired (unexpected)");
                    m.ReleaseMutex();
                    return;
                }
                Log("  Thread B: timed out - the mutex is owned by Thread A");
                Log("  Thread B: now waiting without a timeout...");
                m.WaitOne();
                Log("  Thread B: acquired the mutex after A released it");
                m.ReleaseMutex();
            });

            holder.Start();
            waiter.Start();
            holder.Join();
            waiter.Join();
        });
    }

    private async Task SemaphoreDemoAsync()
    {
        _semaphoreCurrent = 0;
        _semaphoreMax = 0;
        using var semaphore = new SemaphoreSlim(3, 3);
        Log("8 tasks compete for a semaphore that admits only 3 at a time...");

        var tasks = Enumerable.Range(1, 8).Select(id => Task.Run(async () =>
        {
            await semaphore.WaitAsync();
            try
            {
                int now = Interlocked.Increment(ref _semaphoreCurrent);
                lock (_lockObject) { if (now > _semaphoreMax) _semaphoreMax = now; }
                Log($"  Task {id} entered  (inside now: {now})");
                await Task.Delay(500);
            }
            finally
            {
                Interlocked.Decrement(ref _semaphoreCurrent);
                semaphore.Release();
                Log($"  Task {id} left");
            }
        })).ToArray();

        await Task.WhenAll(tasks);
        Log($"Maximum tasks inside at once: {_semaphoreMax} (limit was 3)");
    }

    private async Task ProducerConsumerAsync()
    {
        using var queue = new BlockingCollection<int>(boundedCapacity: 3);
        Log("1 producer, 2 consumers, bounded queue (capacity 3): the producer blocks when the queue is full.");

        var producer = Task.Run(() =>
        {
            for (int i = 1; i <= 10; i++)
            {
                queue.Add(i);
                Log($"  Producer: produced {i}");
                Thread.Sleep(80);
            }
            queue.CompleteAdding();
            Log("  Producer: finished (CompleteAdding)");
        });

        var consumers = Enumerable.Range(1, 2).Select(c => Task.Run(() =>
        {
            foreach (int item in queue.GetConsumingEnumerable())
            {
                Log($"  Consumer {c}: consumed {item}");
                Thread.Sleep(200);
            }
            Log($"  Consumer {c}: queue drained, exiting");
        })).ToList();

        await Task.WhenAll(consumers.Append(producer));
    }

    private async Task ParallelDemoAsync()
    {
        ThreadPool.GetMinThreads(out int minWorkers, out int minIo);
        ThreadPool.GetMaxThreads(out int maxWorkers, out int maxIo);
        Log($"CPU cores: {Environment.ProcessorCount}. Thread pool workers min/max: {minWorkers}/{maxWorkers}, I/O min/max: {minIo}/{maxIo}");

        const int N = 30_000_000;
        await Task.Run(() =>
        {
            var sw = Stopwatch.StartNew();
            double sequential = 0;
            for (int i = 1; i <= N; i++) sequential += Math.Sqrt(i);
            long seqMs = sw.ElapsedMilliseconds;

            sw.Restart();
            double parallel = 0;
            var sync = new object();
            Parallel.For(1, N + 1, () => 0.0,
                (i, _, local) => local + Math.Sqrt(i),
                local => { lock (sync) { parallel += local; } });
            long parMs = sw.ElapsedMilliseconds;

            Log($"Sum of sqrt(1..{N:N0}): sequential {seqMs} ms, Parallel.For {parMs} ms " +
                $"(speed-up x{(double)seqMs / Math.Max(1, parMs):0.0}); results equal: {Math.Abs(sequential - parallel) < 1e-3 * sequential}");
        });
    }

    private async Task DeadlockDemoAsync()
    {
        var a = new object();
        var b = new object();
        bool t1Done = false, t2Done = false;
        Log("Two threads lock A and B in OPPOSITE order - the classic deadlock recipe.");
        Log("Using Monitor.TryEnter with a timeout lets one thread detect the problem and back off.");

        await Task.Run(() =>
        {
            var t1 = new Thread(() =>
            {
                lock (a)
                {
                    Log("  T1: holds A, wants B");
                    Thread.Sleep(300);
                    if (Monitor.TryEnter(b, 1000))
                    {
                        try { t1Done = true; Log("  T1: got B too"); }
                        finally { Monitor.Exit(b); }
                    }
                    else Log("  T1: could not get B within 1 s -> deadlock suspected, releasing A and backing off");
                }
            });

            var t2 = new Thread(() =>
            {
                lock (b)
                {
                    Log("  T2: holds B, wants A");
                    Thread.Sleep(300);
                    if (Monitor.TryEnter(a, 3000))
                    {
                        try { t2Done = true; Log("  T2: got A too (T1 backed off and released it)"); }
                        finally { Monitor.Exit(a); }
                    }
                    else Log("  T2: could not get A within 3 s");
                }
            });

            t1.Start(); t2.Start();
            t1.Join(); t2.Join();
        });

        Log($"Result: T1 completed={t1Done}, T2 completed={t2Done}. No permanent deadlock occurred. " +
            "Other cures: always lock in one global order, or avoid holding two locks.");
    }
}
