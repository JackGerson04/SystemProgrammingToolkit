namespace SystemProgrammingToolkit.Common;

/// <summary>
/// Common layout for every module window:
///   description  /  button toolbar  /  optional input area  /  live log console.
/// Derived forms only add buttons (AddButton / AddAsyncButton) and call Log().
/// Log() is thread-safe so background threads can report progress.
/// </summary>
public abstract class ModuleFormBase : Form
{
    protected readonly FlowLayoutPanel ButtonPanel;
    protected readonly Panel ContentPanel;
    protected readonly RichTextBox LogBox;

    protected ModuleFormBase(string title, string description, bool contentFills = false, int contentHeight = 0)
    {
        Text = title;
        Size = new Size(1050, 740);
        MinimumSize = new Size(820, 560);
        StartPosition = FormStartPosition.CenterParent;
        Font = new Font("Segoe UI", 9F);

        var layout = new TableLayoutPanel
        {
            Dock = DockStyle.Fill,
            ColumnCount = 1,
            RowCount = 4,
            Padding = new Padding(8)
        };
        layout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
        layout.RowStyles.Add(new RowStyle(SizeType.Absolute, 40));   // description
        layout.RowStyles.Add(new RowStyle(SizeType.AutoSize));       // buttons
        if (contentFills)
        {
            layout.RowStyles.Add(new RowStyle(SizeType.Percent, 55)); // content (e.g. list)
            layout.RowStyles.Add(new RowStyle(SizeType.Percent, 45)); // log
        }
        else
        {
            layout.RowStyles.Add(new RowStyle(SizeType.Absolute, contentHeight));
            layout.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
        }

        var header = new Label
        {
            Text = description,
            Dock = DockStyle.Fill,
            TextAlign = ContentAlignment.MiddleLeft,
            ForeColor = Color.DimGray
        };

        ButtonPanel = new FlowLayoutPanel
        {
            Dock = DockStyle.Fill,
            AutoSize = true,
            AutoSizeMode = AutoSizeMode.GrowAndShrink,
            WrapContents = true,
            Margin = new Padding(0)
        };

        ContentPanel = new Panel { Dock = DockStyle.Fill, Margin = new Padding(0) };

        LogBox = new RichTextBox
        {
            Dock = DockStyle.Fill,
            ReadOnly = true,
            BackColor = Color.FromArgb(24, 24, 24),
            ForeColor = Color.Gainsboro,
            Font = new Font("Consolas", 9.5F),
            BorderStyle = BorderStyle.None,
            WordWrap = false,
            DetectUrls = false,
            HideSelection = false
        };
        var menu = new ContextMenuStrip();
        menu.Items.Add("Clear log", null, (_, _) => LogBox.Clear());
        LogBox.ContextMenuStrip = menu;

        layout.Controls.Add(header, 0, 0);
        layout.Controls.Add(ButtonPanel, 0, 1);
        layout.Controls.Add(ContentPanel, 0, 2);
        layout.Controls.Add(LogBox, 0, 3);
        Controls.Add(layout);
    }

    /// <summary>Thread-safe: may be called from any thread.</summary>
    public void Log(string message)
    {
        if (IsDisposed || LogBox.IsDisposed) return;

        if (LogBox.InvokeRequired)
        {
            try { LogBox.BeginInvoke(new Action(() => Log(message))); }
            catch (Exception ex) when (ex is ObjectDisposedException or InvalidOperationException) { }
            return;
        }

        LogBox.AppendText($"[{DateTime.Now:HH:mm:ss.fff}] {message}{Environment.NewLine}");
        LogBox.ScrollToCaret();
    }

    protected void LogError(Exception ex) => Log($"ERROR ({ex.GetType().Name}): {ex.Message}");

    protected Button AddButton(string text, Action action)
    {
        var button = NewButton(text);
        button.Click += (_, _) =>
        {
            try { action(); }
            catch (Exception ex) { LogError(ex); }
        };
        return button;
    }

    protected Button AddAsyncButton(string text, Func<Task> action)
    {
        var button = NewButton(text);
        button.Click += async (_, _) =>
        {
            button.Enabled = false;
            try { await action(); }
            catch (Exception ex) { LogError(ex); }
            finally { if (!button.IsDisposed) button.Enabled = true; }
        };
        return button;
    }

    /// <summary>Forces the next button onto a new row (groups buttons visually).</summary>
    protected void NewRow()
    {
        if (ButtonPanel.Controls.Count > 0)
            ButtonPanel.SetFlowBreak(ButtonPanel.Controls[ButtonPanel.Controls.Count - 1], true);
    }

    private Button NewButton(string text)
    {
        var button = new Button
        {
            Text = text,
            AutoSize = true,
            AutoSizeMode = AutoSizeMode.GrowAndShrink,
            MinimumSize = new Size(110, 30),
            Margin = new Padding(3),
            Padding = new Padding(6, 0, 6, 0)
        };
        ButtonPanel.Controls.Add(button);
        return button;
    }

    protected static Label MakeLabel(string text) =>
        new() { Text = text, AutoSize = true, Margin = new Padding(6, 8, 2, 0) };

    public static string FormatBytes(double bytes)
    {
        string[] units = { "B", "KB", "MB", "GB", "TB" };
        int i = 0;
        while (bytes >= 1024 && i < units.Length - 1) { bytes /= 1024; i++; }
        return $"{bytes:0.##} {units[i]}";
    }
}
